1. Unzip the downloaded file "GRE AWA Sim.zip"

2. Make sure that you have the latest Java Runtime Environment (JRE) installed. Usually, it is already included in your operating system. 
Please run "check-java.bat" to check your Java version

3. Double-click 'GRE AWA Sim.jar' to run this app. Or right click the app -> Open With -> Java Platform SE

If you have any question, please visit the wiki page: http://weelyoung.com/wiki

*****************************